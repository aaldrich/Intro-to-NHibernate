NHibernate folder is the fully constructed project if you want to look at a working example.

NHibernate Demo Empty is the Demo project without mapping files filled, Providers, or Unit Tests. Feel free to try and fill these in as a good practice run.

NHibernate.pptx is the slide as displayed at the Alabama Code Camp